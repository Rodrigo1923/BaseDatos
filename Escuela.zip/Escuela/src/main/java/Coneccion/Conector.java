/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author rous2
 */
public class Conector {
    
    Connection conectar = null;
    
    String usuario = "postgres";
    String contraseña = "123456";
    String bd = "Escuela";
    String ip = "localhost";
    String puerto = "5432";
    
    String cadena = "jdbc:postgresql://"+ip+":"+puerto+"/"+bd;
    
    public Connection Conectar(){
        try{
            Class.forName("org.postgresql.Driver");
            conectar = DriverManager.getConnection(cadena, usuario, contraseña);
            System.out.println("Coneccion establecida");
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Error al conectar a la base de datos"+e);
        }
        return conectar;
    }
    
}
